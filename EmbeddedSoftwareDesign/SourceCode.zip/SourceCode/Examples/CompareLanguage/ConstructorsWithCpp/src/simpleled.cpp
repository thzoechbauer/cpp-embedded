/********************************************//**
* \file     simpleled.cpp
* \brief    Implementation of simple Led class.
* \author   Thomas Z�chbauer
* \version  V1.0
* \date     07-August-2015
***********************************************/

// no implementation

#include "simpleled.h"
